// src/components/ui/SelectContent.js
import React from 'react';

const SelectContent = ({ children }) => {
  return <div>{children}</div>;
};

export default SelectContent;
