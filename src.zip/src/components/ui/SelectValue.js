// src/components/ui/SelectValue.js
import React from 'react';

const SelectValue = ({ placeholder }) => {
  return <div>{placeholder}</div>;
};

export default SelectValue;
