// src/components/ui/TableHeader.js
import React from 'react';

const TableHeader = ({ children }) => {
  return <thead>{children}</thead>;
};

export default TableHeader;
